/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab6;

/**
 *
 * @author Lenovo
 */
class OddThread extends Thread {
    @Override
    public void run() {
        for (int i = 1; i <= 10; i += 2) { // Xuất số lẻ
            System.out.println(i);
            try {
                Thread.sleep(10); // Chờ 10 mili giây
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}


