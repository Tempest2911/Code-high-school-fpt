/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab6;

/**
 *
 * @author Lenovo
 */
public class EvenThread extends Thread {
    @Override
    public void run() {
        for (int i = 2; i <= 10; i += 2) { // Xuất số chẵn
            System.out.println(i);
            try {
                Thread.sleep(15); // Chờ 15 mili giây
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

