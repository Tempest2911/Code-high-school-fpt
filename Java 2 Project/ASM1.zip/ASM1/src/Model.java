/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author drago
 */
public class Model {
        private int maSV;
        private String hoTen;
        private float tiengAnh;
        private float tinHoc;
        private float giaoDucTC;

    public Model() {
    }

    public Model(int maSV, String hoTen, float tiengAnh, float tinHoc, float giaoDucTC) {
        this.maSV = maSV;
        this.hoTen = hoTen;
        this.tiengAnh = tiengAnh;
        this.tinHoc = tinHoc;
        this.giaoDucTC = giaoDucTC;
    }

    public int getMaSV() {
        return maSV;
    }

    public void setMaSV(int maSV) {
        this.maSV = maSV;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public float getTiengAnh() {
        return tiengAnh;
    }

    public void setTiengAnh(float tiengAnh) {
        this.tiengAnh = tiengAnh;
    }

    public float getTinHoc() {
        return tinHoc;
    }

    public void setTinHoc(float tinHoc) {
        this.tinHoc = tinHoc;
    }

    public float getGiaoDucTC() {
        return giaoDucTC;
    }

    public void setGiaoDucTC(float giaoDucTC) {
        this.giaoDucTC = giaoDucTC;
    }
        
        
        
                
}
