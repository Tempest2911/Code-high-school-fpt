function toggleMenu() {
    const navLinks = document.getElementById('dropdown-mobile');
    if (navLinks.style.display === "block") {
        navLinks.style.display = "none";
    } else {
        navLinks.style.display = "block";
    }
}