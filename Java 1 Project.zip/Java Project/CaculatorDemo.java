public class CaculatorDemo {
    public static void main(String[] args) {
        int a = 6;
        int b = 8;
        int c = 7;

        int total = a * 2 + b + c;

        double sqrt = Math.sqrt(total);

        System.out.println("Total= " + total);
        System.out.println("Square root: " + sqrt);
    }

}