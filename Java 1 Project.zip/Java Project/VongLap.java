public class VongLap {
    public static void main(String[] args) {
        int a;

        for(a=1;a<=10;a++){
            System.out.printf("%d ", a);
        }
    }
}
