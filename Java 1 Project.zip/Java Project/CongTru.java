public class CongTru {
    public static void main(String[] args) {
        int a = 3;
        int b = 6;

        int c = a + b;

        System.out.println("Sum cua c la: " + c);
    }
}