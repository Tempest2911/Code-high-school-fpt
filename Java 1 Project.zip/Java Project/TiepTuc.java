import java.util.Scanner;

public class TiepTuc {
    public static void main(String[] args) {
        int a;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Nhap a: ");
        a = scanner.nextInt();

        
    }
}
